<html>
	<head></head>
<body>

<h1> Materiał zaliczeniowy z zajęć 3 </h1>
<ul>
<li>Wprowadzanie do PHP - 01</li>
 <ul>
	<li><a href="for.php">Zadanie 1 - modyfikacja pętli for</a></li>
	<li><a href="each.php">Zadanie 2 - modyfikacja pętli foreach</a></li>	
 </ul>
</ul>

<ul>
<li>Formularze PHP - 02</li>
 <ul>
	<li><a href="przyklad2.html">Zadanie 1 - pokoloruj parzyste</a></li>
        <li><a href="przyklad3.php">Zadanie 2 - komunikat złe hasło lub login</a></li>
 </ul>
</ul>
<ul>
 <li>Wykorzystanie PHP & MYSQL</li>
  <ul>
	<li><a href="samochody/">Zadanie 1 - blokowanie konta po 3 błędnych próbach</a></li>
	<li><a href="samochody/">Zadanie 2 - rozszerzenie formularza o pojemność, poduszki, abs, esp</a></li>
        <li><a href="samochody/">Zadanie 3 - rozszerzenie o możliwość edycji formularza</a></li>
	<li><a href="samochody/">Zadanie 4 - potwierdzenie JavaScript przed operacją usunięcia rekordu</a></li>
  </ul>
</ul>
<p>Materiały można pobrać z tego miejsca -> <a href="gronowski_iz04p02.zip">tutaj</a></p>
</html>
