<?php

$pdo = new PDO('mysql:host=mysql10.mydevil.net;dbname=m1104_samochody', 'm1104_samochody', 'Testowy12');

?>